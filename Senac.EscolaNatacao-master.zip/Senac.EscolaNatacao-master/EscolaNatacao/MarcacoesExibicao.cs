﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EscolaNatacao
{
    public class MarcacoesExibicao
    {
        public string Data { get; set; }
        public string Horario { get; set; }
        public string Aula { get; set; }
        public string Professor { get; set; }
        public string Aluno { get; set; }
    }
}
