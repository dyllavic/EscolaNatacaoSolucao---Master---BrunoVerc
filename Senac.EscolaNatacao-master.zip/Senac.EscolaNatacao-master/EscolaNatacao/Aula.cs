﻿namespace EscolaNatacao
{
    public class Aula
    {
        public string Nome { get; set; }
        public Professor ProfessorAula { get; set; }
        public int QuantidadeMaxima { get; set; }
    }
}
